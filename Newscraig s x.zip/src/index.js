require('dotenv').config();

const { startPolling } = require('./services/rssService');
const { logger } = require('./utils/logger');

async function bootstrap() {
  logger.info('NEWSCRAIG PRO starting...');
  await startPolling();
}

bootstrap().catch((err) => {
  logger.error(err);
  process.exit(1);
});
